AIBlocksWorld
=============
in order to run the gui you need to download and installs pyqt4 and all of its' dependencies.
description in the link:
http://www.riverbankcomputing.com/software/pyqt/download

after that in order to run the gui run the command:

python blocksWorldGUI.py